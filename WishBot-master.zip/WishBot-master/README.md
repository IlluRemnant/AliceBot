# Wishbot
A Discord bot made by Wish written with the Discord js API.

At this time no support will be given for users wishing to run this bot themselves, Sorry!
